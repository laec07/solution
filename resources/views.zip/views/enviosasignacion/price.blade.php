            <label>Total:</label>
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text">
                  Q
                </span>
              </div>
              <input type="number" class="form-control" name="total_msj" id="total_msj" step="0.01" value="{{$tarifas->total}}">
            </div>