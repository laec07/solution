            <label>Total:</label>
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text">
                  Q
                </span>
              </div>
              <input type="number" class="form-control" name="total_msjE" id="total_msjE" step="0.01" value="{{$tarifas->total}}">
            </div>