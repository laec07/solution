


<div class="modal fade " id="HistoryPay" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Historial de pagos || Envío No. <span id="info_envioh"></span>   </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">


          <input type="hidden" name="no_envio_h" id="no_envio_h" >


          <div class="table-responsive" id="dataHistory"></div>

                  

      </div>
      <div class="modal-footer">


      </div>
    </div>
  </div>
</div>
